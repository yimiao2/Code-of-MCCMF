function [AUC,stack_x,stack_y] = calculate_auc(targets,predicts)
%function AUC=calculate_auc(targets,predicts)
	%if nargin > 1
		[~,i] = sort(predicts,'descend');
	%	targets = targets(i);
%	end

roc_y = targets(i);
stack_x = cumsum(roc_y==0)/sum(roc_y==0);
stack_y = cumsum(roc_y==1)/sum(roc_y==1);
AUC=sum((stack_x(2:length(roc_y))-stack_x(1:length(roc_y)-1)).*stack_y(2:length(roc_y)));
end