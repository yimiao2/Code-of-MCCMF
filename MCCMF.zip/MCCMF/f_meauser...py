# -*- coding:utf-8 -*-
#time:2020/5/16
import numpy as np
import xlrd

def excel2m(path):#读excel数据转为矩阵函数
    data = xlrd.open_workbook(path)
    table = data.sheets()[0] # 获取excel中第一个sheet表
    nrows = table.nrows  # 行数
    ncols = table.ncols  # 列数
    datamatrix = np.zeros((nrows, ncols))
    for x in range(ncols):
        cols = table.col_values(x)
        cols1 = np.matrix(cols)  # 把list转换为矩阵进行矩阵操作
        datamatrix[:, x] = cols1 # 把数据进行存储
    return datamatrix



def f1(y_hat, y_true, THRESHOLD=0.5):
    '''
    y_hat是未经过sigmoid函数激活的
    输出的f1为Marco-F1
    '''
    epsilon = 1e-7
    y_hat = y_hat > THRESHOLD
    y_hat = np.int8(y_hat)
    tp = np.sum(y_hat * y_true, axis=0)
    fp = np.sum((1 - y_hat) * y_true, axis=0)
    fn = np.sum(y_hat * (1 - y_true), axis=0)
    tn = np.sum((1 - y_hat)*(1 - y_true),axis=0)

    s = (tp + tn)/(tp + fp + tn + fn + epsilon)
    p = tp / (tp + fp + epsilon)  # precision epsilon的意义在于防止分母为0，否则当分母为0时python会报错
    r = tp / (tp + fn + epsilon)  # recall

    f1 = 2 * p * r / (p + r + epsilon)
    f1 = np.where(np.isnan(f1), np.zeros_like(f1), f1)

    return np.mean(f1),np.mean(s),np.mean(p),np.mean(r)




y_true=excel2m(r'E:\pyc_code\f-meauser\y.xlsx')
y_hat=excel2m(r'E:\pyc_code\f-meauser\WBNPMD_predict.xlsx')

f1,s,p,r = f1(y_hat, y_true)
print('F1 score:', f1)
print('Accu:', s)
print('precision:', p)
print('recall:', r)