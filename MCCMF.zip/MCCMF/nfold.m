function [auc_res,stack_x,stack_y]=nfold(Y,Sd,St,pred_fn,nr_fold,seed,cv_setting,use_WKNKN,K,eta,use_W_matrix)
%nfold is a helper function of crossValidation.m. Depending on the
%specified CV setting (or scenario) and supplied "seed", it divides the
%interaction matrix into "nr_fold" folds, performs a cross validation
%experiment and then reports the results (AUPR/AUC) back to
%crossValidation.m.
%
% INPUT:
%  Y:           matrix to be modified
%  Sd:          pairwise row similarities matrix
%  St:          pairwise column similarities matrix
%  pred_fn:     function/script of algorithm to be used for DTI prediction
%  nr_fold:     number of folds in cross validation experiment
%  seed:        seed used for random sampling
%  cv_setting:  drug prediction case or target prediction case
%
% OUTPUT:
%  auc_res:     AUC result
%  aupr_res:    AUPR result
%

    len = numel(Y);
    rng('default')
    rng(seed);
    rand_ind = randperm(len);



    AUCs  = zeros(1,nr_fold);
    for i=1:nr_fold
        % leave out random drug-target pair
            test_ind = rand_ind((floor((i-1)*len/nr_fold)+1:floor(i*len/nr_fold))');
            left_out = test_ind;
        % predict with test set being left out
        y2 = Y;
        y2(test_ind) = 0;   % test set = ZERO
        fprintf('****');
        y3 = pred_fn(y2,Sd,St,cv_setting,nr_fold,left_out,use_WKNKN,K,eta,use_W_matrix); % predict!

        % compute evaluation metrics based on obtained prediction scores
        [AUCs(i),stack_x,stack_y] = returnEvaluationMetrics(Y(test_ind)',y3(test_ind)');
        diary off;  diary on;
    end

    auc_res = mean(AUCs);
  
    fprintf('\n');
    fprintf('      AUC: %g\n',   auc_res);
    disp('==========================');
        
    plot(stack_x,stack_y,'r','linewidth',2);
    xlabel('FPR');
    ylabel('TPR');
    legend('MCCMF');

end