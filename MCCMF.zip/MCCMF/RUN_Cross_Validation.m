clear   % clear workspace
clc     % clear console screen

diary off;  diary on;   % to save console output

%--------------------------------------------------------------------------

% The location of the folder that contains the data
path='C:\Users\dell\Desktop\prediction\GRMF\data\';

% the different datasets
datasets={'gg'};

% CLASSIFIER -------------------------------
classifier='mccmf';
% ------------------------------------------

% Parameters and Options -------------------
%WKNKN
use_WKNKN = 1;     
K = 5;              % number of K nearest known neighbors
eta = 0.7;          % decay rate (also used by WNN in RLS-WNN)

%weight matrix W 
use_W_matrix = 0;
% ------------------------------------------

% CROSS VALIDATION SETTING -----------------
cv_setting = 'cv_p';    % PAIR PREDICTION CASE
% ------------------------------------------

% CROSS VALIDATION PARAMETERS --------------
m = 10;  % number of n-fold experiments (repetitions)
n = 5; % the 'n' in "n-fold experiment"
% ------------------------------------------

%warning off     % to be used when many unnecessary warnings are being produced

%--------------------------------------------------------------------------
% Terminology:
% Y = Interaction matrix
% Sd = Drug similarity matrix
% St = Target similarity matrix
% ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
for ds=[1]
    disp('--------------------------------------------------------------');
    % LOAD DATA
    [Y,Sd,St,Did,Tid]=getdata(path,datasets{ds});
    % PREDICT (+ print evaluation metrics)
    crossValidation(Y',Sd,St,classifier,cv_setting,m,n,use_WKNKN,K,eta,use_W_matrix);
    disp('--------------------------------------------------------------');
    diary off;  diary on;
end
% ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
disp('==============================================================');
diary off;