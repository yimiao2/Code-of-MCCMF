function crossValidation(Y,Sd,St,classifier,cv_setting,m,n,use_WKNKN,K,eta,use_W_matrix)
%crossValidation runs cross validation experiments
%
% INPUT:
%  Y:           matrix to be modified
%  Sd:          pairwise drug similarities matrix
%  St:          pairwise target similarities matrix
%  classifier:  algorithm to be used for DTI prediction
%  m:           number of repetitions of n-fold cross validation
%  n:           number of folds in each n-fold cross validation

    % prediction method
    pred_fn = str2func(['alg_' classifier]);

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%% cross validation setting %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    % parameters
    fprintf('%i�۽�����֤\n',n);      % #folds

    % seeds
    rng('shuffle');
    seeds = randi(10000,1,m);

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


    % cross validation (m repetitions of n-fold experiments)
    AUCs  = zeros(1,m);
    for i=1:m
        seed = seeds(i);
        [AUCs(i)] = nfold(Y,Sd,St,pred_fn,n,seed,cv_setting,use_WKNKN,K,eta,use_W_matrix);
        diary off;  diary on;
    end
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    % display evaluation results
    fprintf('\n FINAL AVERAGED RESULTS\n\n');
    fprintf('     AUC (std): %g\t(%g)\n',   mean(AUCs),  std(AUCs));
    diary off;  diary on;


end